<?php
/**
 * Redux Framework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * Redux Framework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Redux Framework. If not, see <http://www.gnu.org/licenses/>.
 *
 * @package     ReduxFramework
 * @author      Dovy Paukstys
 * @version     3.1.5
 */

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

// Don't duplicate me!
if( !class_exists( 'ReduxFramework_custom_field' ) ) {

    /**
     * Main ReduxFramework_custom_field class
     *
     * @since       1.0.0
     */
    class ReduxFramework_custom_field extends ReduxFramework {
    
        /**
         * Field Constructor.
         *
         * Required - must call the parent constructor, then assign field and value to vars, and obviously call the render field function
         *
         * @since       1.0.0
         * @access      public
         * @return      void
         */
        function __construct( $field = array(), $value ='', $parent ) {
        
            
            $this->parent = $parent;
            $this->field = $field;
            $this->value = $value;

            if ( empty( $this->extension_dir ) ) {
                $this->extension_dir = trailingslashit( str_replace( '\\', '/', dirname( __FILE__ ) ) );
                $this->extension_url = site_url( str_replace( trailingslashit( str_replace( '\\', '/', ABSPATH ) ), '', $this->extension_dir ) );
            }    

            // // Set default args for this field to avoid bad indexes. Change this to anything you use.
            // $defaults = array(
            //     'options'           => array(),
            //     'stylesheet'        => '',
            //     'output'            => true,
            //     'enqueue'           => true,
            //     'enqueue_frontend'  => true
            // );
            // $this->field = wp_parse_args( $this->field, $defaults );            
            // print_r($defaults);
        }

        /**
         * Field Render Function.
         *
         * Takes the vars and outputs the HTML for the field in the settings
         *
         * @since       1.0.0
         * @access      public
         * @return      void
         */
        public function render() {
        
            // HTML output goes here
            // No errors please
            $defaults = array(
                'top-left'    => true,
                'top-right'   => true,
                'bottom-left' => true,                
                'bottom-right'  => true,
                'all'    => true,                
            );

            $this->field = wp_parse_args( $this->field, $defaults );

            $defaults = array(
                'top-left'    => '',
                'top-right'   => '',
                'bottom-left' => '',                
                'bottom-right'  => '',
            );

            $this->value = wp_parse_args( $this->value, $defaults );



            $value = array(
                // 'top-left'    => isset( $this->value['border-radius-top-left'] ) ? filter_var( $this->value['border-radius-top-left'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) : filter_var( $this->value['top-left'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ),
                // 'top-right'    => isset( $this->value['border-radius-top-right'] ) ? filter_var( $this->value['border-radius-top-right'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) : filter_var( $this->value['top-right'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ),
                // 'bottom-left'    => isset( $this->value['border-radius-bottom-left'] ) ? filter_var( $this->value['border-radius-bottom-left'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) : filter_var( $this->value['bottom-left'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ),
                // 'bottom-right'    => isset( $this->value['border-radius-bottom-right'] ) ? filter_var( $this->value['border-radius-bottom-right'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) : filter_var( $this->value['bottom-right'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ),

                'top-left'    => isset( $this->value['border-radius-top-left'] ) ? $this->value['border-radius-top-left'] : $this->value['top-left'],
                'top-right'    => isset( $this->value['border-radius-top-right'] ) ? $this->value['border-radius-top-right'] : $this->value['top-right'],
                'bottom-left'    => isset( $this->value['border-radius-bottom-left'] ) ? $this->value['border-radius-bottom-left'] : $this->value['bottom-left'],
                'bottom-right'    => isset( $this->value['border-radius-bottom-right'] ) ? $this->value['border-radius-bottom-right'] : $this->value['bottom-right'],
            );

            print_r($value);
            // print_r($defaults);
            
            if ( ( isset( $this->value['radius'] ) || isset( $this->value['border-radius'] ) ) ) {
                if ( isset( $this->value['border-radius'] ) && ! empty( $this->value['border-radius'] ) ) {
                    $this->value['radius'] = $this->value['border-radius'];
                }

                $this->value['radius'] = $this->stripAlphas($this->value['radius']);

                $value['top-left']    = $this->value['radius'];
                $value['top-right']  = $this->value['radius'];
                $value['bottom-left'] = $this->value['radius'];
                $value['bottom-right']   = $this->value['radius'];
            }

            $this->value = $value;

            print_r($value);

            $defaults = array(
                'top-left'    => '',
                'top-right'   => '',
                'bottom-left' => '',                
                'bottom-right'  => '',                
            );

            $this->value = wp_parse_args( $this->value, $defaults );

            
            echo '<input type="hidden" class="field-units" value="px">';

            if ( isset( $this->field['all'] ) && $this->field['all'] == true ) {
                echo '<div class="field-border-radius-input input-prepend"><span class="add-on"><i class="el el-fullscreen icon-large"></i></span><input type="text" class="redux-border-radius-all redux-border-radius-input mini ' . $this->field['class'] . '" placeholder="' . __( 'All', 'redux-framework' ) . '" rel="' . $this->field['id'] . '-all" value="' . $this->value['top-left'] . '"></div>';
            }

            echo '<input type="hidden" class="redux-border-radius-value" id="' . $this->field['id'] . '-top-left" name="' . $this->field['name'] . $this->field['name_suffix'] . '[border-radius-top-left]" value="' . ( $this->value['top-left'] ? $this->value['top-left'] . 'px' : '' ) . '">';
            echo '<input type="hidden" class="redux-border-radius-value" id="' . $this->field['id'] . '-top-right" name="' . $this->field['name'] . $this->field['name_suffix'] . '[border-radius-top-right]" value="' . ( $this->value['top-right'] ? $this->value['top-right'] . 'px' : '' ) . '">';
            echo '<input type="hidden" class="redux-border-radius-value" id="' . $this->field['id'] . '-bottom-left" name="' . $this->field['name'] . $this->field['name_suffix'] . '[border-radius-bottom-left]" value="' . ( $this->value['bottom-left'] ? $this->value['bottom-left'] . 'px' : '' ) . '">';
            echo '<input type="hidden" class="redux-border-radius-value" id="' . $this->field['id'] . '-bottom-right" name="' . $this->field['name'] . $this->field['name_suffix'] . '[border-radius-bottom-right]" value="' . ( $this->value['bottom-right'] ? $this->value['bottom-right'] . 'px' : '' ) . '">';

            if ( ! isset( $this->field['all'] ) || $this->field['all'] !== true ) {
                /**
                 * Top
                 * */
                if ( $this->field['top-left'] === true ) {
                    echo '<div class="field-border-radius-input input-prepend"><span class="add-on"><i class="el el-arrow-up icon-large"></i></span><input type="text" class="redux-border-radius-top-left redux-border-radius-input mini ' . $this->field['class'] . '" placeholder="' . __( 'Top Left', 'redux-framework' ) . '" rel="' . $this->field['id'] . '-top-left" value="' . $this->value['top-left'] . '"></div>';
                }

                /**
                 * Right
                 * */
                if ( $this->field['top-right'] === true ) {
                    echo '<div class="field-border-radius-input input-prepend"><span class="add-on"><i class="el el-arrow-right icon-large"></i></span><input type="text" class="redux-border-radius-top-right redux-border-radius-input mini ' . $this->field['class'] . '" placeholder="' . __( 'Top Right', 'redux-framework' ) . '" rel="' . $this->field['id'] . '-top-right" value="' . $this->value['top-right'] . '"></div>';
                }

                /**
                 * Bottom
                 * */
                if ( $this->field['bottom-left'] === true ) {
                    echo '<div class="field-border-radius-input input-prepend"><span class="add-on"><i class="el el-arrow-down icon-large"></i></span><input type="text" class="redux-border-radius-bottom-left redux-border-radius-input mini ' . $this->field['class'] . '" placeholder="' . __( 'Bottom Left', 'redux-framework' ) . '" rel="' . $this->field['id'] . '-bottom-left" value="' . $this->value['bottom-left'] . '"></div>';
                }

                /**
                 * Left
                 * */
                if ( $this->field['bottom-right'] === true ) {
                    echo '<div class="field-border-radius-input input-prepend"><span class="add-on"><i class="el el-arrow-left icon-large"></i></span><input type="text" class="redux-border-radius-bottom-right redux-border-radius-input mini ' . $this->field['class'] . '" placeholder="' . __( 'Bottom Right', 'redux-framework' ) . '" rel="' . $this->field['id'] . '-bottom-right" value="' . $this->value['bottom-right'] . '"></div>';
                }
            }            

        }
    
        /**
         * Enqueue Function.
         *
         * If this field requires any scripts, or css define this function and register/enqueue the scripts/css
         *
         * @since       1.0.0
         * @access      public
         * @return      void
         */
        public function enqueue() {

            $extension = ReduxFramework_extension_custom_field::getInstance();
        
            wp_enqueue_script(
                'redux-field-icon-select-js', 
                $this->extension_url . 'field_custom_field.js', 
                array( 'jquery' ),
                time(),
                true
            );

            wp_enqueue_style(
                'redux-field-icon-select-css', 
                $this->extension_url . 'field_custom_field.css',
                time(),
                true
            );
        
        }
        
        /**
         * Output Function.
         *
         * Used to enqueue to the front-end
         *
         * @since       1.0.0
         * @access      public
         * @return      void
         */        
        public function output() {

            

                if ( isset( $this->field['all'] ) && true == $this->field['all'] ) {
                    $borderRadius = isset( $this->value['border-radius'] ) ? $this->value['border-radius'] : '0px';
                    $val         = isset( $this->value['border-radius-top-left'] ) ? $this->value['border-radius-top-left'] : $borderRadius;

                    $this->value['border-radius-top-left']    = $val;
                    $this->value['border-radius-top-right'] = $val;
                    $this->value['border-radius-bottom-left']   = $val;
                    $this->value['border-radius-bottom-right']  = $val;
                }

                $borderRadius = '';
                if ( isset( $this->value['border-radius'] ) ) {
                    $borderRadius = $this->value['border-radius'];
                }

                $this->field['top-left']    = isset( $this->field['top-left'] ) ? $this->field['top-left'] : true;
                $this->field['top-right'] = isset( $this->field['top-right'] ) ? $this->field['top-right'] : true;
                $this->field['bottom-left']   = isset( $this->field['bottom-left'] ) ? $this->field['bottom-left'] : true;
                $this->field['bottom-right']  = isset( $this->field['bottom-right'] ) ? $this->field['bottom-right'] : true;

                if ( $this->field['top-left'] === true ) {
                    $cleanValue['top-left'] = ! empty( $this->value['border-radius-top-left'] ) ? $this->value['border-radius-top-left'] : $borderRadius;
                }

                if ( $this->field['top-right'] == true ) {
                    $cleanValue['top-right'] = ! empty( $this->value['border-radius-top-right'] ) ? $this->value['border-radius-top-right'] : $borderRadius;
                }

                if ( $this->field['bottom-left'] === true ) {
                    $cleanValue['bottom-left'] = ! empty( $this->value['border-radius-bottom-left'] ) ? $this->value['border-radius-bottom-left'] : $borderRadius;
                }

                if ( $this->field['bottom-right'] === true ) {
                    $cleanValue['bottom-right'] = ! empty( $this->value['border-radius-bottom-right'] ) ? $this->value['border-radius-bottom-right'] : $borderRadius;
                }

                
                //absolute, padding, margin
                if ( ! isset( $this->field['all'] ) || $this->field['all'] != true ) {
                    foreach ( $cleanValue as $key => $value ) {
                        if (!empty($value)) {
                            $style .= 'border-radius-' . $key . ':' . $value . ' ' . ';';
                        }
                    }
                } else {
                    if (!empty($cleanValue['top-left'])) {
                        $style .= 'border-radius:' . $cleanValue['top-left'] . ' ' . ';';
                    }
                }

                if ( ! empty( $this->field['output'] ) && is_array( $this->field['output'] ) ) {
                    $keys = implode( ",", $this->field['output'] );
                    
                    if (!empty($style)) {
                        $this->parent->outputCSS .= $keys . "{" . $style . '}';
                    }
                }

                if ( ! empty( $this->field['compiler'] ) && is_array( $this->field['compiler'] ) ) {
                    $keys = implode( ",", $this->field['compiler'] );
                    
                    if (!empty($style)) {
                        $this->parent->compilerCSS .= $keys . "{" . $style . '}';
                    }
                }



            
            
        }        
        
    }
}
