<?php


	require_once(get_template_directory() . '/assets/functions/widgets/widget-twoColImgTxt.php');

	require_once(get_template_directory() . '/assets/functions/widgets/widget-threeColImgTxt.php');
	
	require_once(get_template_directory() . '/assets/functions/widgets/widget-image.php');

	require_once(get_template_directory() . '/assets/functions/widgets/widget-latest-recent-post.php');

?>