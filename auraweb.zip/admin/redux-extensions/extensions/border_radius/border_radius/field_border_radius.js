/*
 Field Border (border)
 */

/*global redux_change, wp, redux*/

(function( $ ) {
    
})( jQuery );